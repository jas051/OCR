clc;
close all;
clear all;
load('C.mat')
imagen=imread('test.png');
figure(1)
imshow(imagen);
title('INPUT IMAGE WITH NOISE')
if size(imagen,3)==3 
    imagen=rgb2gray(imagen);
end
threshold = graythresh(imagen);
imagen =~im2bw(imagen,threshold);
imagen = bwareaopen(imagen,50);
pause(1)
figure(2)
imshow(~imagen);
title('INPUT IMAGE WITHOUT NOISE')
[L Ne]=bwlabel(imagen);
propied=regionprops(L,'BoundingBox');
hold on
for n=1:size(propied,1)
    rectangle('Position',propied(n).BoundingBox,'EdgeColor','g','LineWidth',2)
end
hold off
pause (1)
%% Objects extraction
l=cell(4,100);
[H,L]=size(imagen);
% Line segmentation
line=prod(~imagen,2);
i=1;y=0;
while i~=length(line)
    if line(i)==0
        st=i;
        while line(i)==0
            i=i+1;
           stp=i;
        end
        y=y+1;
        l{2,y}=(~imagen(st:stp,:));
    end
    i=i+1;
end
% Word Extraction
k=0;
for j=1:y
%     if j>1
%         k=k+1;
%     end
temp=l{2,j};
words=prod(temp);
i=1;
while i~=length(words)
    if words(i)==0
        st=i;
        while words(i)==0
            i=i+1;
           stp=i;
        end
        k=k+1;
        l{3,k}=temp(:,st:stp);
        [featureVector,hogVisualization] = extractHOGFeatures(l{3,k});
        l{4,k}=featureVector;
        figure(3)
        imshow(l{3,k});
        pause(0.5);
    end
    i=i+1;
end
end

%% testing Phase
for z=1:k
test=l{4,z};
% Designing KNN classifier 
for i=1:26
    [~,t]=size(test);
    [~,s]=size(C{2,i});
    if t<s
        test=[test zeros(1,s-t)];
    elseif t>s
        C{2,i}=[C{2,i} zeros(1,t-s)];
    end
        d(i)=sqrt(sum((test-C{2,i}).^2));
end
% Letter detection stage
d_sorted=sort(d);
for i=1:26
    [~,t]=size(test);
    [~,s]=size(C{2,i});
    if t<s
        test=[test zeros(1,s-t)];
    elseif t>s
        C{2,i}=[C{2,i} zeros(1,t-s)];
    end
    if d_sorted(1,1)==sqrt(sum((test-C{2,i}).^2))
        detected(z)=C{1,i};
    end
end
clear test;
end
fid = fopen('Mymatrix.txt','wt');
fprintf(fid,'%s',detected);
fclose(fid);