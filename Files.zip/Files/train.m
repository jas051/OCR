clc;
close all;
%% Read Image
z=9;
imagen=imread('9.png');
%% Show image
% figure(1)
% imshow(imagen);
% title('INPUT IMAGE WITH NOISE')
%% Convert to gray scale
if size(imagen,3)==3 % RGB image
    imagen=rgb2gray(imagen);
end
%% Convert to binary image
threshold = graythresh(imagen);
imagen =~im2bw(imagen,threshold);
%% Remove all object containing fewer than 30 pixels
imagen = bwareaopen(imagen,50);
pause(1)
%% Show image binary image
% figure(2)
% imshow(~imagen);
% title('INPUT IMAGE WITHOUT NOISE')
%% Objects extraction
l=cell(4,100);
% C=cell(4,100);
[H,L]=size(imagen);
% Line segmentation
line=prod(~imagen,2);
i=1;k=0;
while i~=length(line)
    if line(i)==0
        st=i;
        while line(i)==0
            i=i+1;
           stp=i;
        end
        k=k+1;
        l{2,k}=(~imagen(st:stp,:));
    end
    i=i+1;
end
% Word Extraction
k=0;
for j=1:5
temp=l{2,j};
words=prod(temp);
i=1;
while i~=length(words)
    if words(i)==0
        st=i;
        while words(i)==0
            i=i+1;
           stp=i;
        end
        k=k+1;
        l{3,k}=temp(:,st:stp);
        [featureVector,hogVisualization] = extractHOGFeatures(l{3,k});
        C{2,z}=featureVector;
%         imshow(l{3,k});
%         pause(0.5);
    end
    i=i+1;
end
end